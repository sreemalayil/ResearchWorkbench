
# Copyright Sreekumar  Pillai, 2017
# Camera dataset available free for public use from https://perso.telecom-paristech.fr/eagan/class/igr204/datasets


colfilter1 <- c("Model","Release.date","Max.resolution","Low.resolution",
                "Effective.pixels","Zoom.wide..W.","Zoom.tele..T.",
                "Normal.focus.range","Macro.focus.range","Storage.included",	
                "Weight..inc..batteries.","Dimensions","Price")

col.names <- c("model","rel.date","max.resln","low.resln","eff.pixels","zoom.wide","zoom.tele","norm.focus.range",
               "macro.focus.range","stor.included","weight.incl.batt","dimensions","price")



camera.df <- camera.df[colfilter1]
colnames(camera.df) <- col.names


##convert some of the variables into factors
camera.df$model <- factor(camera.df$model)

#Removing the special character from Model name
camera.df$model <-  revalue(camera.df$model, c("Agfa ePhoto CL30 Clik!"="Agfa ePhoto CL30 Clik"))

#Removing the line for the data type
camera.df <- camera.df[-c(1), ]

#Check NA values using NAHunter
NAhunter(camera.df)


#Convert the column into numeric type
#camera.df$rel.date  <- as.numeric(camera.df$rel.date)
camera.df$max.resln  <- as.numeric(camera.df$max.resln)
camera.df$low.resln  <- as.numeric(camera.df$low.resln)
camera.df$eff.pixels  <- as.numeric(camera.df$eff.pixels)
camera.df$zoom.wide  <- as.numeric(camera.df$zoom.wide)
camera.df$zoom.tele  <- as.numeric(camera.df$zoom.tele)
camera.df$norm.focus.range  <- as.numeric(camera.df$norm.focus.range)
camera.df$macro.focus.range  <- as.numeric(camera.df$macro.focus.range)
camera.df$stor.included  <- as.numeric(camera.df$stor.included)
camera.df$weight.incl.batt  <- as.numeric(camera.df$weight.incl.batt)
camera.df$dimensions  <- as.numeric(camera.df$dimensions)
camera.df$price  <- as.numeric(camera.df$price)

##Subsetting the Dataset 

## Subset of Camera dataset for a specific year
##camera.df1 <- subset(camera.df, select=c("model","rel.date","max.resln","low.resln","eff.pixels","zoom.wide","zoom.tele","norm.focus.range",
##                                         "macro.focus.range","stor.included","weight.incl.batt","dimensions","price")
##                     ,subset=(rel.date=='1994'))

#Set the Working Directory to the root directory
#setwd("D:/BitBucket/researchworkbench")


