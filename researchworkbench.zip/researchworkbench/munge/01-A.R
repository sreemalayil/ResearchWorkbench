
# Copyright Sreekumar  Pillai, 2017
# Camera dataset available free for public use from https://perso.telecom-paristech.fr/eagan/class/igr204/datasets


#Set the Working Directory to src
#setwd("D:/BitBucket/researchworkbench")

#Reference to the CSV file
file.csv = "data/Camera.csv"

#Read the csv file into a data frame
camera.df <- read.csv(file.csv,  strip.white = TRUE,na.strings=c(";","NA","NaN"), header = TRUE,sep=";")
