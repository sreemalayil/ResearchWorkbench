

## This is a function that will count the number of NAs in a particular column in a dataset
NAhunter<-function(dataset) { 
  find.NA<-function(variable) { 
    if(is.numeric(variable)){ 
      n<-length(variable) 
      mean<-mean(variable, na.rm=T) 
      median<-median(variable, na.rm=T) 
      sd<-sd(variable, na.rm=T) 
      NAs<-is.na(variable) 
      total.NA<-sum(NAs) 
      percent.missing<-total.NA/n 
      descriptives<-data.frame(n,mean,median,sd,total.NA,percent.missing) 
      rownames(descriptives)<-c(" ") 
      Case.Number<-1:n 
      Missing.Values<-ifelse(NAs>0,"Missing Value"," ") 
      missing.value<-data.frame(Case.Number,Missing.Values) 
      missing.values<-missing.value[ which(Missing.Values=='Missing Value'),] 
      list("NUMERIC DATA","DESCRIPTIVES"=t(descriptives)) 
    } else{ 
      n<-length(variable) 
      NAs<-is.na(variable) 
      total.NA<-sum(NAs) 
      percent.missing<-total.NA/n 
      descriptives<-data.frame(n,total.NA,percent.missing) 
      rownames(descriptives)<-c(" ") 
      Case.Number<-1:n 
      Missing.Values<-ifelse(NAs>0,"Missing Value"," ") 
      missing.value<-data.frame(Case.Number,Missing.Values) 
      missing.values<-missing.value[ which(Missing.Values=='Missing   
        Value'),] 
      list("CATEGORICAL DATA","DESCRIPTIVES"=t(descriptives)) 
    } 
  } 
  dataset<-data.frame(dataset) 
  options(scipen=100) 
  options(digits=2) 
  lapply(dataset,find.NA) 
}  


## Replaces NAs with the given string
NAreplace <- function(x, replString){  
    {
      x[is.na(x)] <- replString
      replace(x, is.na(x), replString) 
      return(x)
    }
}



## Find outliers
findOutlier <- function(data, cutoff = 3) {
  ## Calculate the sd
  sds <- apply(data, 2, sd, na.rm = TRUE)
  ## Identify the cells with value greater than cutoff * sd (column wise)
  result <- mapply(function(d, s) {
    which(d > cutoff * s)
  }, data, sds)
  result
}
